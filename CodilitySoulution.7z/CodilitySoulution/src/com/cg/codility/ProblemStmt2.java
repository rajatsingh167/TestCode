package com.cg.codility;

import java.util.Iterator;
import java.util.LinkedList;

public class ProblemStmt2 {

	public static void main(String[] args) {
		System.out.println("Codility Solution of Problem Statement 2");
		ProblemStmt2 pstm2 = new ProblemStmt2();
		int length=pstm2.LengthOfLinkedList();
		System.out.println("\nLength of Linked List  = > "+length);
	}

	public int LengthOfLinkedList() {
		int length = 0;
		LinkedList<String> LinkedList = new LinkedList<String>();

		LinkedList.add("a");
		LinkedList.add("b");
		LinkedList.add("c");
		LinkedList.add("a");
		LinkedList.add("b");
		LinkedList.add("c");
		LinkedList.add("a");
		LinkedList.add("b");
		LinkedList.add("c");

		Iterator<String> itr = LinkedList.iterator();
		while (itr.hasNext()) {
			length++;
			System.out.print(itr.next()+" ");
		}

		return length;
	}

}

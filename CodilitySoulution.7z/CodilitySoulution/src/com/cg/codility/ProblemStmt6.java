package com.cg.codility;
/*
 * Given a table elements  with the following structure:
 * 
 * create table elements (
 *    v integer not null
 *   );
 *   
 * write an SQL query that returns the sum of the numbers in column  V.
 * 
 * For example, given:
 * 
 *  V
 * ----
 *  2
 *  10
 *  20
 *  10
 *  
 *  your query should return 42.
 *   
 */

public class ProblemStmt6 {

	public static void main(String[] args) {
		int V[] = { 2, 10, 10, 10, 10 };
		System.out.println("Total Sum of the array is ==> " + new ProblemStmt6().solution(V));

	}

	public int solution(int[] V) {
		int sum=0;
		for(int i=0;i<V.length;i++){
			sum=sum+ V[i];
		}
	
	
		return sum;
	}
}

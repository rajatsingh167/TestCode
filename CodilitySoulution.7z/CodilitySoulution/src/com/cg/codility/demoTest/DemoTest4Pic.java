package com.cg.codility.demoTest;
/*
 * doc 1
 * 
 */

// best on is IndicesLessthenPQ
public class DemoTest4Pic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//int A[] = { 0, 3, 3, 7, 5, 3, 11, 1 };
		int A[] ={1,4,7,3,3,5};
		//int A[] ={0,999999999};
		//int A[]={3};
		System.out.println("test" + new DemoTest4Pic().solution(A));
	}

	public int solution(int[] A) {
		int minDistance = 0;
		int curDistance = 0;
		boolean flag=true;
		
		for (int i = 0; i < A.length; i++) {
			int start = i + 1;
			for (int j = start; j < A.length; j++) {
				for (int k = A.length-1 ; k >0 ; k--) {
					if (A[i] < A[j]) {
						if (A[i] < A[k] && A[k] < A[j]) {
							break;
						} else {
							flag=false;
							curDistance = A[i] - A[j];
							curDistance=Math.abs(curDistance);
							if (curDistance < minDistance) {
								minDistance = curDistance;
							
							}
						}
					} else {
						if (A[i] > A[k] && A[k] > A[j]) {
							break;
						} else {
							flag=false;
							curDistance = A[i] - A[j];
							curDistance=Math.abs(curDistance);
							if (curDistance < minDistance) {
								minDistance = curDistance;
					
							}
						}
					}
				}
			}
		
		}
		if(minDistance > 100000000){
			return -1;
		}
		if(flag){
			return -2;
		}
		return minDistance;
	}
}

package com.cg.codility.demoTest;

public class TreeTask {

	public static void main(String[] args) {
		int T[] = { 9, 1, 4, 9, 0, 4, 8, 9, 0, 1 };
		int X[] = new TreeTask().solution(T);
		/*
		 * for(int i=0 ;i<X.length ;i++) System.out.println(X[i]);
		 */
	}

	public int[] solution(int[] T) {
		int A[] = null;
		int capital = 0;
		int count1 = -1;
		int tempArray[] = new int[T.length];
		int tempArray2[] = new int[T.length];
		int tempArray3[] = new int[T.length];
		for (int i = 0; i < T.length; i++) {
			if (T[i] == i) {
				capital = i;
			}
		}
		System.out.println("Capital "+capital);
		int i = 0;
		for (int j = 0; j < T.length; j++) {
		
			if (T[j] == capital &&  j!=capital) {
				System.out.println("kno"+j);
				count1 = count1 + 1;
				tempArray2[i] = j;
			}
		}
		tempArray[0]=count1;
		count1=0;
		for(int k=0 ;k<tempArray2.length ;k++){
			System.out.println(" tets "+tempArray2[k]);
		}
	 i=0;		
		for (int j = 0; j < T.length; j++) {
			for(int l=0 ; l<tempArray2.length ;l++){
				System.out.println("value to chk "+T[j]);
			 if(T[j]==tempArray2[l]){
				 count1=count1+1;
				 tempArray3[i]=j;
				 
			 }
			}
		}
		tempArray[1]=count1;
		for(int k=0 ;k<tempArray3.length ;k++){
			System.out.println(" tevxddsvts "+tempArray3[k]);
		}
		
		
		
		
		
		
		
		
		
		for(int k=0 ;k<tempArray.length ;k++){
			System.out.println(" tets "+tempArray[k]);
		}
		return A;
	}

}

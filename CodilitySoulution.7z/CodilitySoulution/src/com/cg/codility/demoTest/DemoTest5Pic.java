package com.cg.codility.demoTest;

public class DemoTest5Pic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[] = { 5, 4, -3, 6, -3, 2, -3, 5 };
		System.out.println("test anser == > " + new DemoTest5Pic().solution(A));

	}

	public int solution(int[] A) {
		int lengthod = 0;
		int lengthev = 0;
		int i, j, k;
		for (i = 0; i < A.length; i++) {
			for (j = i + 2; j < A.length;) {

				if (A[i] == A[j]) {
					j = j + 2;

				} else {

					lengthev = j;
					break;
				}

			}

			for (k = i + 3; k < j && k < A.length;) {
				if (A[i + 1] == A[k]) {
					k = k + 2;

				} else {
					lengthod = k;
					break;
				}
			}

		}
		if (lengthev < lengthod) {
			return lengthev - 1;
		} else {
			return lengthod - 1;
		}
	}
}

package com.cg.codility.demoTest;
/*
 * This is a demo task.
 * Write a function:
 * 
 * class Solution { public int solution(int[] A); }
 * 
 * that, given an array A of N integers, returns the smallest positive integer (greater than 0) that does not occur in A.
 * For example, given A = [1, 3, 6, 4, 1, 2], the function should return 5.
 * Given A = [1, 2, 3], the function should return 4.
 * Given A = [−1, −3], the function should return 1.
 * Assume that:
 * •N is an integer within the range [1..100,000];
 * •each element of array A is an integer within the range [−1,000,000..1,000,000].
 * 
 * Complexity:
 * 
 * •expected worst-case time complexity is O(N);
 * •expected worst-case space complexity is O(N), beyond input storage (not counting the storage required for input arguments).
 * 
 * Elements of input arrays can be modified
 *  
 */
import java.util.Arrays;

public class DemoTest12 {

	public static void main(String[] args) {
		int A[] = { 1, 3, 6, 4, 1, 2 };
		// int A[]={-1,-3};
		// int A[]={1,2,3};
		// int A[]={3};
		// int A[]={-1,-2,-3,1,2,6};
		// int A[] = { 2, 3, 4, -3, };
		// int A[]={-1,1,2,3};
		System.out.println(new DemoTest12().Solution(A));
	}

	public int Solution(int[] A) {

		Arrays.sort(A);
		int temp1 = 0;
		int temp2 = 0;
		int length = A.length;
		int num = 0;
		if (A[length - 1] <= 0) {
			return 1;
		}
		for (int k = 0; k < A.length; k++) {
			if (A[k] < 0) {
				continue;
			} else {
				num = k;
				break;
			}
		}
		if (A[num] > 1) {
			return 1;
		}
		for (int i = num; i < A.length - 1; i++) {
			temp1 = A[i];
			temp2 = A[i + 1];
			if ((temp1 == temp2 || temp2 == temp1 + 1)) {
				continue;
			} else if ((temp1 + 1) <= 0) {
				continue;
			} else {
				return temp1 + 1;
			}
		}
		int highest = A[length - 1];

		return highest + 1;
	}
}

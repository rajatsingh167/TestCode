package com.cg.codility;

/*
 *   You are given a string S consisting of N brackets, opening �(� and/or closing�)�.
 *   The goal is to split S into two parts such that the number of opening brackets in the first part is equal to the number
 *   of closing brackets in the second part. More formally, we are looking for an integer k such that:
 *   0<=K<=N and The number of opening brackets in the K leading characters of S is the same as the number of 
 *   closing brackets in the N-K trailing characters of S.
 *   For example, given S=�(())))(�,k equals 4,because:
 *   The first characters of S,�(())�,contain two opening brackets and
 *   The remaining three brackets of S,�))(�,contain two closing brackets.
 *   Write a function: 
 *   Class Solution{public int solution(String s);}
 *   That, given string S, returns a value for K that satisfies the above conditions. It can be shown that such an index K 
 *   always exists and is unique.
 *   For example, given S=�(())))(�,the function should return 4, as explained above.
 *   Assume that:
 *   N is an integer within the range[0..100000];
 *   String s consists only of the characters�(� and /or�)�.
 *   Complexity :
 *   Expected worst case time complexity is 0(N);
 *   Expected worst case space complexity is 0(1)(not counting the storage required for input arguments).
 *    
 */
public class ProblemStmt15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String S = "(())";
		int i=new ProblemStmt15().solution(S);
		System.out.println("The value for K == > "+i);
	}

	public int solution(String S) {
		int openingCount = 0;
		int closingCount = 0;
		int valueToreturn=0;
		for (int i = 0; i < S.length(); i++) {
			char closingBrac = S.charAt(i);
			if (closingBrac != ')') {
				closingCount = closingCount + 1;
			}
		}
		for(int i=S.length()-1 ; i>=0;i--){
			if(openingCount == closingCount){
				valueToreturn=i;
				valueToreturn=valueToreturn+1;
				return valueToreturn;
			}
			char Brac =S.charAt(i);
			if(Brac ==')'){
				openingCount++;
			}else if(Brac =='('){
				closingCount--;
			}
			
		}
		return -1;
	}

}

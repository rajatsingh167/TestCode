package com.cg.codility;

import java.util.Scanner;

public class CodilitySolution {

	public static void main(String[] args) {
		
		int arraySize,i,value,sum;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Codility Solution");
		System.out.println("Enter the Array Size ==> ");
		arraySize=sc.nextInt();
		
		int inputValue[]=new int[arraySize];
		
		System.out.println("PLease enter the "+ arraySize +" value in array");
		for( i=0; i<arraySize;i++){
			value=sc.nextInt();
			inputValue[i]=value;
		}
		Solution solution= new Solution();
		sum=solution.solution(inputValue);
		System.out.print("and their absolute sum equals ==>"+sum);
		
		
	
		
		
	}

}

package com.cg.codility;

/*
 * Write a function:
 * Class solution{public int solution(int A,int B);}
 * That,given two non-negative integers A and B, returns the number of bits set to 1 in the binary representation of the number A*B.
 * e.g., given A=3 and B=7 the function should return 3, because the binary representation of A*B=3*7=21 is 10101 and it contains 
 * three bits set to 1.
 * Assume that :
 * A and B are integers within the range[0..100000000].
 * In your solution, focus on correctness. The performance of your solution will not be the focus of the assessment.
 * 
 * */

public class ProblemStmt14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A = 25;
		int B = 25;
		System.out.println("the number of bits set to 1 in the binary representation of the number A*B == > "
				+ new ProblemStmt14().solution(A, B));

	}

	public int solution(int A, int B) {
		int C = 0;
		int result=0;
		if (A == 0 && B == 0) {
			return 0;
		} else {
			C = A * B;
			System.out.println("A*B  = > "+C);
			String binaryIntInSt=Integer.toBinaryString(C);
			System.out.println("binaryIntInSt== > "+binaryIntInSt);
			char[] number =binaryIntInSt.toCharArray();
			for(int i=0 ; i<number.length;i++){
				if(number[i]=='1'){
					result=result+1;
				}
			}
			
			return result;
		}
	}

}

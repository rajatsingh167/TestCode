package com.cg.codility;

public class Solution {

	int depth = 0;
	int length;

	public int solution(int[] A) {
		int arrSize, i, minSum, sum, minStart = 100, minEnd = 100;
		minSum = 100;
		arrSize = A.length;
		System.out.print("The Input Value from Solution  is ==> ");
		for (i = 0; i < arrSize; i++) {
			System.out.print(A[i] + " ");
		}
		System.out.println();
		for (i = 0; i < arrSize; i++) {
			for (int j = i + 1; j < arrSize; j++) {
				sum = A[i] + A[j];
				sum = Math.abs(sum);
				if (sum < minSum) {
					minSum = sum;
					minStart = i;
					minEnd = j;
				}
			}
		}
		System.out.println("The Minimum abs slices is (" + minStart + "," + minEnd + ")");
		return minSum;

	}

	public int problmStmt1(int[] A) {
		
		return depth;
	}

}

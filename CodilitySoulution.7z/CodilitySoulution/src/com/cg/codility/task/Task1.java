package com.cg.codility.task;

public class Task1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

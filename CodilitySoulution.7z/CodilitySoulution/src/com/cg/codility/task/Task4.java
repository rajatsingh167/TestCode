package com.cg.codility.task;

/*
 * Task 4:
 * You are given an implementation of a function:
 * int solution(int A[], int N);
 * which accepts as input a non-empty zero-indexed array A consisting of N integers.
 * The function works slowly on large input data and the goal is to optimize it so as to achieve better time and/or space complexity.
 * The optimized function should return the same result as the given implementation for every input that satisfies the assumptions.
 * For example, given array A such that:
 *   A[0] = 4
 *   A[1] = 6
 *   A[2] = 2
 *   A[3] = 2
 *   A[4] = 6
 *   A[5] = 6
 *   A[6] = 1
 *   
 * the function returns 4.
 * Assume that:
 * N is an integer within the range [1..100,000];
 * each element of array A is an integer within the range [1..N].
 *
 * Complexity:
 * expected worst-case time complexity is O(N);
 * expected worst-case space complexity is O(N), beyond input storage (not counting the storage required for input arguments).
 *
 * Elements of input arrays can be modified.
 * The original code is:
 * int solution(int *A, int N) {
 *     int result = 0;
 *     int i, j;
 *      for (i = 0; i  N; i++)
 *      for (j = 0; j  N; j++)
 *      if (A[i] == A[j])
 *      if (abs(i - j) result)
 *      result = abs(i - j);
 *      return result;
 *  }
 * 
 * 
 */
public class Task4 {

	public static void main(String[] args) {
		int A[] = { 4, 6, 2, 2, 6, 6, 1 };
		System.out.println(new Task4().solution(A, 7));
	}

	int solution(int[] A, int N) {
		int result = 0;
		int i, j;
		for (i = 0; i < N; i++)
			for (j = i; j < N; j++)
				if (A[i] == A[j])
					if (Math.abs(i - j) > result){
						result = Math.abs(i - j);
						System.out.println("i value ==>     "+i +"\t J value == >  "+j +"\nA[i] value==>   "+ A[i]+"\t A[j] value==> "+A[j]);
					}
		return result;
	}

}

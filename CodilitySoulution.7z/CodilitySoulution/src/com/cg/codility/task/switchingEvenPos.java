package com.cg.codility.task;

public class switchingEvenPos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[] = { 5, 4, -3, 4, -3, 5, -3, 5 };
		System.out.println("maximum switching slice is==> " + new switchingEvenPos().solution(A));
	}

	public int solution(int[] A) {
		int i = 0;
		int j = 1;
		int count1 = 0, count2 = 1;
		if(A[A.length]==0){
			return 0;
		}
		while (i < A.length-2 && j < A.length-2) {
			System.out.println("i==> "+i+"\t J===> "+j);
			System.out.println("A[i]==> " + A[i] + "\t A[i+2]==> " + A[i + 2]);
			System.out.println("A[j]==> " + A[j] + "\t A[j+2]==> " + A[j + 2]);
			if (A[i] == A[i + 2] ) {
				System.out.println("1");
				if (A[j] == A[j + 2] ) {
					System.out.println("2");
					count1 = count1 + 4;
				} else {
					System.out.println("3");
					count1 = count1 + 3;

				}
			} else {
				System.out.println("4");

			}

			System.out.println("Final count1 == > " + count1 + " \t Final count2 ====> " + count2);
			if (count2 < count1) {
				System.out.println("5");
				count2 = count1;
			}
			count1 = 0;
			System.out.println("Final count1 == > " + count1 + " \t Final count2 ====> " + count2);
			i = i + 1;
			j = j + 1;
		}

		return count2;
	}

}

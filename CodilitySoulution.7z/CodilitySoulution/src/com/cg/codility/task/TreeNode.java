package com.cg.codility.task;

import java.util.List;

public class TreeNode {
	
	 public List<Integer> value;
	 public TreeNode next;
	public List<Integer> getValue() {
		return value;
	}
	public void setValue(List<Integer> value) {
		this.value = value;
	}
	public TreeNode getNext() {
		return next;
	}
	public void setNext(TreeNode next) {
		this.next = next;
	}
	@Override
	public String toString() {
		return "TreeNode [value=" + value + ", next=" + next + "]";
	}
	
	
	 
	 

}

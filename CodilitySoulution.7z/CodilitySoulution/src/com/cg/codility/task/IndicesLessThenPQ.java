package com.cg.codility.task;

import java.util.Arrays;

public class IndicesLessThenPQ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int A[] = { 0, 3, 3, 7, 5, 3, 11, 1 };
		// int A[] = { 1, 4, 7, 3, 3, 5 };
		// int A[] ={0,999999999,7};
		 int A[]={3};
		System.out.println("test" + new IndicesLessThenPQ().solution(A));
	}

	public int solution(int[] A) {
		int curDist = 0;
		int maxDist = 0;
		boolean flag = false;

		int[] sortedArray = A.clone();
		Arrays.sort(sortedArray);
		for (int i = 0; i < A.length; i++) {
			for (int j = (i + 1); j < A.length; j++) {
				int position1 = Arrays.binarySearch(sortedArray, A[i]);
				int position2 = Arrays.binarySearch(sortedArray, A[j]);
				int pos1 = Math.min(position1, position2);
				int pos2 = Math.max(position1, position2);
				if (pos1 == pos2) {
					flag = false;
				} else if (pos2 == pos1 + 1) {
					flag = true;
				} else {
					for (int k = pos1 + 1; k <= pos2 - 1; k++) {
						if (sortedArray[k] == A[i] || sortedArray[k] == A[j]) {
							flag = true;
						} else {
							flag = false;
							break;
						}
					}
				}
				if (flag) {
					curDist = Math.abs(j - i);
					if (maxDist < curDist) {
						maxDist = curDist;
					}
				}
			}
		}
		return maxDist;
	}
}

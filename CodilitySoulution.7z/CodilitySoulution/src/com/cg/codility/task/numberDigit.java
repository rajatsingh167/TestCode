package com.cg.codility.task;

public class numberDigit {

	public static void main(String[] args) {

		int A = 13;
		System.out.println("Result ==> " + new numberDigit().solution(A));
	}

	public int solution(int N) {
		int result = 0;
		if (N <= 0) {
			return 0;
		}
		for (int i = 1; i <= N; i++) {
			System.out.println("i  == > " + i + " result= =>" + returnNumber(i));
			result = result + returnNumber(i);
		}

		return result;

	}

	public int returnNumber(int number) {
		if (number <= 0) {
			return 0;
		} else {
			if (number % 10 == 1) {
				return 1 + returnNumber(number / 10);
			} else {
				return returnNumber(number / 10);
			}
		}
	}
}

package com.cg.codility.task;

import java.util.ArrayList;
import java.util.List;

public class TressTaskFinal {
	public static void main(String[] args) {
		int T[] = { 9, 1, 4, 9, 0, 4, 8, 9, 0, 1 };
		int X[] = new TressTaskFinal().solution(T);
		System.out.println();
		for(int i=0 ;i<X.length ;i++) 
			System.out.print("\t"+X[i]);
		 
	}

	public int[] solution(int[] T) {
		
		int[] intArray = new int[T.length];
		List<Integer> ls = new ArrayList<>();
		List<Integer> ls1 = new ArrayList<>();
		List<Integer> ls2 = new ArrayList<>();
		List<Integer> ls3 = new ArrayList<>();
		List<Integer> ls4 = new ArrayList<>();
		List<Integer> ls5 = new ArrayList<>();

		TreeNode ts = new TreeNode();
		TreeNode ts1 = new TreeNode();
		TreeNode ts2 = new TreeNode();
		TreeNode ts3 = new TreeNode();
		TreeNode ts4 = new TreeNode();
		TreeNode ts5 = new TreeNode();
		int capital = 0;
		int count=0;

		for (int i = 0; i < T.length; i++) {
			if (T[i] == i) {
				capital = i;
				ls.add(capital);
			}
		}
		ts.setValue(ls);
		ts.setNext(ts1);
		for (int i = 0; i < T.length; i++) {
			if (T[i] == capital && i != capital) {
				capital = i;
				ls1.add(i);
				count=count+1;
			}
			
		}
		intArray[0]=count;
		count=0;
		ts1.setValue(ls1);
		ts1.setNext(ts2);
		
		for (int k = 0; k < ls1.size(); k++) {
			for (int j = 0; j < T.length; j++) {
				if (T[j] == ls1.get(k)) {
					ls2.add(j);
					count=count+1;
				}
				
			}
			ts2.setValue(ls2);
			ts2.setNext(ts3);
		
		}
		intArray[1]=count;
		count=0;
		System.out.println("sdfgsdgf"+ts);
		for (int k = 0; k < ls2.size(); k++) {
			for (int j = 0; j < T.length; j++) {
				if (T[j] == ls2.get(k) ) {
					ls3.add(j);
					count=count+1;
				}
			}
			ts3.setValue(ls3);
			ts3.setNext(ts4);
			
		}
		
		intArray[2]=count;
		count=0;
		System.out.println("sdfgsdfsdfsdgf"+ts);
		for (int k = 0; k < ls3.size(); k++) {
			System.out.println("K == >"+ls3.get(k));
			for (int j = 0; j < T.length; j++) {
				System.out.println("1st for " + T[j]);
				if (T[j] == ls3.get(k) ) {
					System.out.println("Match");
					ls4.add(j);
					count=count+1;
				}
				
			}
			ts4.setValue(ls4);
			ts4.setNext(ts5);
		
		}
		intArray[3]=count;
		count=0;
		System.out.println(ts);
		return intArray;
	}
}

package com.cg.answer;

public class Question1Answer {

	/*
	 * an array A consisting of N integers, returns the maximum sum of any slice of A.
	 * For example, given array A such that:
	 * A[0] = 3  A[1] = 2  A[2] = -6
	 * A[3] = 4  A[4] = 0
	 * 3, 4) is a slice of A that has sum 4,
	 * (2, 2) is a slice of A that has sum −6
	 * (0, 1) is a slice of A that has sum 5
	 * no other slice of A has sum greater than (0, 1).
	 * Return 5 and Print Slice (0 ,1)
	 * 
	 * */
	public static void main(String[] args) {
		
		int a[]={3,2,-6,4,0};
		System.out.println(new Question1Answer().solution(a));
	}
	
	public int solution(int[] A){
		int maxSilice = -1000000;
	    int previousMaxSlice = -1000000;

		for(int i=0;i<A.length;i++){
			previousMaxSlice = A[i] > previousMaxSlice+A[i]?A[i]:previousMaxSlice+A[i];
			maxSilice = previousMaxSlice > maxSilice ?previousMaxSlice:maxSilice;

		}
		return maxSilice;
	}

}

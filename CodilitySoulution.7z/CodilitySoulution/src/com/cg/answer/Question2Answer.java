package com.cg.answer;

/*
 * Find an index of an array such that its value occurs at more than half of indices in the array.
 * A zero-indexed array A consisting of N integers is given. 
 * The dominator of array A is the value that occurs in more than half of the elements of A.
 * For example, consider array A such that
 *  A[0] = 3    A[1] = 4    A[2] =  3
 *  A[3] = 2    A[4] = 3    A[5] = -1
 *  A[6] = 3    A[7] = 3 
 * The dominator of A is 3 because it occurs in 5 out of 8 elements of A 
 * (namely in those with indices 0, 2, 4, 6 and 7) and 5 is more than a half of 8.
 */
public class Question2Answer {

	public static void main(String[] args) {
		int a[] = { 3, 4, 3, 2, 3, -1, 3, 3 };
		System.out.println(new Question2Answer().solution(a));
	}

	public int solution(int[] A){
		int counter=0;
		int value=-1000000000;
		for(int i=0;i<A.length;i++){
			for(int j=0;j<A.length;j++){
				if(A[i]==A[i]){
					counter++;
					value=A[i];
				}
			}
		}
		return value;
	}

}
